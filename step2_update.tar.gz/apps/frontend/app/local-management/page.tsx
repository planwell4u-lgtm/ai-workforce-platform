"use client";

import { createAuth0Client, type Auth0Client } from "@auth0/auth0-spa-js";
import { useEffect, useState } from "react";
import { loadRuntimeConfig } from "../runtime-config";

type WorkspaceTab = "Overview" | "People & access" | "Operations" | "Governance";

interface KnowledgeArticle {
  article_ref: string;
  topic: string;
  question: string;
  answer: string;
  category: string;
  published: boolean;
  created_by: string;
  updated_at: string;
}

const cardStyle = { border: "1px solid #d9e2ec", borderRadius: 12, padding: 20, background: "#f8fbfd" };
const actionStyle = { display: "inline-block", marginTop: 10, color: "#007a99", fontWeight: 700 };

export default function OwnerWorkspacePage() {
  const [auth, setAuth] = useState<Auth0Client>();
  const [signedIn, setSignedIn] = useState(false);
  const [accountEmail, setAccountEmail] = useState("");
  const [accountRef, setAccountRef] = useState("");
  const [grantedPermissions, setGrantedPermissions] = useState<string[]>([]);
  const [authorized, setAuthorized] = useState<boolean | null>(null);
  const [notice, setNotice] = useState("Sign in with a workspace owner account to view Owner Workspace.");
  const [tab, setTab] = useState<WorkspaceTab>("Overview");
  const [token, setToken] = useState("");
  const [apiBaseUrl, setApiBaseUrl] = useState("");

  useEffect(() => {
    void loadRuntimeConfig().then(async (config) => {
      setApiBaseUrl(config.apiBaseUrl);
      const client = await createAuth0Client({
        domain: config.auth0Domain,
        clientId: config.auth0ClientId,
        cacheLocation: "localstorage",
        authorizationParams: {
          audience: config.auth0Audience,
          redirect_uri: `${window.location.origin}/local-management`,
          scope: "openid profile email platform.owner platform.front-desk.configure",
        },
      });
      if (window.location.search.includes("code=") && window.location.search.includes("state=")) {
        await client.handleRedirectCallback();
        window.history.replaceState({}, document.title, "/local-management");
      }
      setAuth(client);
      const isAuthenticated = await client.isAuthenticated();
      setSignedIn(isAuthenticated);
      if (!isAuthenticated) {
        setAuthorized(false);
        return;
      }
      const user = await client.getUser();
      setAccountEmail(user?.email ?? user?.name ?? "Signed-in account");
      setAccountRef(user?.sub ?? "");
      try {
        const tokenString = await client.getTokenSilently({
          authorizationParams: {
            audience: config.auth0Audience,
            scope: "openid profile email platform.owner platform.front-desk.configure",
          },
        });
        setToken(tokenString);
        setGrantedPermissions(tokenPermissions(tokenString));
        let response: Response;
        try {
          response = await fetch(`${config.apiBaseUrl}/v1/access-management?history=1`, {
            headers: { Authorization: `Bearer ${tokenString}` },
          });
        } catch {
          response = await fetch(`${config.apiBaseUrl}/v1/front-desk/destinations`, {
            headers: { Authorization: `Bearer ${tokenString}` },
          });
        }
        if (response.status === 404) {
          response = await fetch(`${config.apiBaseUrl}/v1/front-desk/destinations`, {
            headers: { Authorization: `Bearer ${tokenString}` },
          });
        }
        setAuthorized(response.ok);
        setNotice(response.ok ? "Workspace access confirmed." : `Owner Workspace access check returned ${response.status}.`);
      } catch {
        setAuthorized(false);
        setNotice("This account is not allowed to view Owner Workspace.");
      }
    }).catch(() => {
      setAuthorized(false);
      setNotice("Owner Workspace could not be initialized.");
    });
  }, []);

  async function signIn() {
    if (!auth) return;
    const config = await loadRuntimeConfig();
    await auth.loginWithRedirect({
      authorizationParams: {
        audience: config.auth0Audience,
        redirect_uri: `${window.location.origin}/local-management`,
        scope: "openid profile email platform.owner platform.front-desk.configure",
      },
    });
  }

  async function switchAccount() {
    await auth?.logout({ logoutParams: { returnTo: `${window.location.origin}/local-management` } });
  }

  return (
    <main style={{ maxWidth: 1050, margin: "36px auto", padding: 24, fontFamily: "Arial, sans-serif", color: "#102a43" }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16, borderBottom: "1px solid #d9e2ec", paddingBottom: 18 }}>
        <a href="/" style={{ fontWeight: 800, color: "#007a99", textDecoration: "none" }}>PLANWELL</a>
        <nav style={{ display: "flex", gap: 16 }}>
          <a href="/support">Support</a>
          <a href="/front-desk-admin">Front Desk</a>
        </nav>
        {signedIn ? (
          <span style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap", justifyContent: "end" }}>
            <small style={{ color: "#486581" }}>Signed in as {accountEmail}</small>
            <button
              onClick={() => void switchAccount()}
              disabled={!auth}
              style={{ padding: "10px 14px", border: "1px solid #007a99", borderRadius: 8, background: "white", color: "#007a99", fontWeight: 700 }}
            >
              Switch owner account
            </button>
          </span>
        ) : (
          <button
            onClick={() => void signIn()}
            disabled={!auth}
            style={{ padding: "10px 14px", border: 0, borderRadius: 8, background: "#007a99", color: "white", fontWeight: 700 }}
          >
            Sign in as owner
          </button>
        )}
      </header>
      <section style={{ marginTop: 42 }}>
        <p style={{ color: "#007a99", fontWeight: 700, letterSpacing: 1 }}>WORKSPACE GOVERNANCE</p>
        <h1 style={{ marginBottom: 8 }}>Owner Workspace</h1>
        <p style={{ maxWidth: 720 }}>
          Review the health, people, operations, and governance of your Planwell workspace. Infrastructure credentials and raw customer records remain outside this area.
        </p>
        <p aria-live="polite" style={{ minHeight: 24, color: "#486581" }}>{notice}</p>
        {authorized === null ? (
          <p>Checking workspace access…</p>
        ) : !authorized ? (
          <section style={{ ...cardStyle, maxWidth: 620 }}>
            <h2 style={{ marginTop: 0 }}>Owner access required</h2>
            <p>Only approved owner accounts can open this workspace.</p>
            {signedIn && (
              <>
                <p style={{ color: "#486581" }}>Signed in as: <strong>{accountEmail}</strong></p>
                <p style={{ color: "#486581" }}>Permissions in this sign-in: <strong>{grantedPermissions.length ? grantedPermissions.join(", ") : "none"}</strong></p>
                <p style={{ color: "#486581" }}>Account reference: <strong>{accountRef || "unavailable"}</strong></p>
                <button
                  onClick={() => void switchAccount()}
                  disabled={!auth}
                  style={{ padding: "10px 14px", border: 0, borderRadius: 8, background: "#007a99", color: "white", fontWeight: 700 }}
                >
                  Sign out and use an owner account
                </button>
              </>
            )}
            <p><a href="/support" style={actionStyle}>Return to Support</a></p>
          </section>
        ) : (
          <>
            <nav aria-label="Owner Workspace sections" style={{ display: "flex", flexWrap: "wrap", gap: 8, margin: "30px 0 24px" }}>
              {(["Overview", "People & access", "Operations", "Governance"] as WorkspaceTab[]).map((name) => (
                <button
                  key={name}
                  onClick={() => setTab(name)}
                  style={{
                    padding: "10px 14px",
                    border: `1px solid ${tab === name ? "#007a99" : "#9fb3c8"}`,
                    borderRadius: 999,
                    background: tab === name ? "#007a99" : "white",
                    color: tab === name ? "white" : "#102a43",
                    fontWeight: 700,
                    cursor: "pointer",
                  }}
                >
                  {name}
                </button>
              ))}
            </nav>
            {tab === "Overview" && <Overview />}
            {tab === "People & access" && <PeopleAccess />}
            {tab === "Operations" && <Operations apiBaseUrl={apiBaseUrl} token={token} />}
            {tab === "Governance" && <Governance />}
          </>
        )}
      </section>
    </main>
  );
}

function Overview() {
  return (
    <>
      <section style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16 }}>
        <Status label="Workspace delivery" value="Healthy" detail="The frontend and protected backend are available through the HTTPS gateway." />
        <Status label="Voice boundary" value="Restricted" detail="No telephone route, recording, tools, escalation, or outbound calling are enabled here." />
        <Status label="Access controls" value="Owner managed" detail="Member permissions and their recent changes are reviewed in one controlled place." />
      </section>
      <section style={{ marginTop: 32, ...cardStyle }}>
        <h2 style={{ marginTop: 0 }}>Start here</h2>
        <p>Review access changes, then check Front Desk routes and Support conversations that need attention.</p>
        <a href="/access-management" style={actionStyle}>Review people & access →</a>
      </section>
    </>
  );
}

function PeopleAccess() {
  return (
    <section style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 16 }}>
      <article style={cardStyle}>
        <h2 style={{ marginTop: 0 }}>People & roles</h2>
        <p>Grant or remove Support, Front Desk administrator, and Workspace Owner roles. Every change is recorded.</p>
        <a href="/access-management" style={actionStyle}>Open Access Management →</a>
      </article>
      <article style={cardStyle}>
        <h2 style={{ marginTop: 0 }}>Multiple Owner safeguard</h2>
        <p>Multiple dedicated owners are supported. Assign the Workspace Owner role in Access Management to maintain redundant, resilient governance.</p>
      </article>
    </section>
  );
}

function Operations({ apiBaseUrl, token }: { apiBaseUrl: string; token: string }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <section style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 16 }}>
        <article style={cardStyle}>
          <h2 style={{ marginTop: 0 }}>Support operations</h2>
          <p>Review authenticated conversations and saved Jira escalation outcomes from the Support workspace.</p>
          <a href="/support" style={actionStyle}>Open Support operations →</a>
        </article>
        <article style={cardStyle}>
          <h2 style={{ marginTop: 0 }}>Front Desk operations</h2>
          <p>Review test-only route drafts, health, activation state, and recorded Human Sales requests.</p>
          <a href="/front-desk-admin" style={actionStyle}>Open Front Desk routes →</a>
        </article>
        <article style={cardStyle}>
          <h2 style={{ marginTop: 0 }}>Sales workspace</h2>
          <p>Use the separate Sales workspace for approved sales conversations.</p>
          <a href="/sales" style={actionStyle}>Open Sales →</a>
        </article>
      </section>

      <KnowledgeBaseManager apiBaseUrl={apiBaseUrl} token={token} />
    </div>
  );
}

function KnowledgeBaseManager({ apiBaseUrl, token }: { apiBaseUrl: string; token: string }) {
  const [articles, setArticles] = useState<KnowledgeArticle[]>([]);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");
  const [editingRef, setEditingRef] = useState<string | null>(null);
  const [topic, setTopic] = useState("Support");
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [category, setCategory] = useState("faq");
  const [published, setPublished] = useState(true);

  async function loadArticles() {
    if (!apiBaseUrl || !token) return;
    setLoading(true);
    try {
      const res = await fetch(`${apiBaseUrl}/v1/owner/knowledge`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json() as { articles: KnowledgeArticle[] };
        setArticles(data.articles || []);
      } else {
        setMsg(`Could not load knowledge articles (${res.status}).`);
      }
    } catch {
      setMsg("Failed to connect to knowledge service.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadArticles();
  }, [apiBaseUrl, token]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!question.trim() || !answer.trim()) {
      setMsg("Question and answer are required.");
      return;
    }
    setMsg("Saving article…");
    try {
      const res = await fetch(`${apiBaseUrl}/v1/owner/knowledge`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          article_ref: editingRef || undefined,
          topic: topic.trim() || "General",
          question: question.trim(),
          answer: answer.trim(),
          category,
          published,
        }),
      });
      if (res.ok) {
        setMsg(editingRef ? "Knowledge article updated!" : "New knowledge article created!");
        resetForm();
        await loadArticles();
      } else {
        setMsg(`Save failed (${res.status}).`);
      }
    } catch {
      setMsg("Error saving knowledge article.");
    }
  }

  async function handleDelete(articleRef: string) {
    if (!confirm("Are you sure you want to delete this knowledge article?")) return;
    setMsg("Deleting article…");
    try {
      const res = await fetch(`${apiBaseUrl}/v1/owner/knowledge?article_ref=${encodeURIComponent(articleRef)}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setMsg("Knowledge article deleted.");
        if (editingRef === articleRef) resetForm();
        await loadArticles();
      } else {
        setMsg(`Delete failed (${res.status}).`);
      }
    } catch {
      setMsg("Error deleting knowledge article.");
    }
  }

  function startEdit(article: KnowledgeArticle) {
    setEditingRef(article.article_ref);
    setTopic(article.topic);
    setQuestion(article.question);
    setAnswer(article.answer);
    setCategory(article.category);
    setPublished(article.published);
    setMsg("Editing article…");
  }

  function resetForm() {
    setEditingRef(null);
    setTopic("Support");
    setQuestion("");
    setAnswer("");
    setCategory("faq");
    setPublished(true);
  }

  return (
    <section style={{ ...cardStyle, background: "white", marginTop: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #d9e2ec", paddingBottom: 12, marginBottom: 16 }}>
        <div>
          <h2 style={{ margin: 0, color: "#102a43" }}>Knowledge Base & Dynamic FAQs</h2>
          <small style={{ color: "#486581" }}>Manage live FAQ responses and domain knowledge used by AI chat and voice agents.</small>
        </div>
        <button
          onClick={() => void loadArticles()}
          disabled={loading}
          style={{ padding: "6px 12px", borderRadius: 6, border: "1px solid #9fb3c8", background: "white", cursor: "pointer", fontWeight: 600 }}
        >
          {loading ? "Refreshing…" : "Refresh"}
        </button>
      </div>

      {msg && <div style={{ padding: "10px 14px", borderRadius: 8, background: "#f0f9ff", border: "1px solid #bae6fd", color: "#0369a1", marginBottom: 16 }}>{msg}</div>}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", gap: 24 }}>
        <div>
          <h3 style={{ marginTop: 0, color: "#102a43" }}>{editingRef ? "Edit Knowledge Article" : "Add New FAQ / Article"}</h3>
          <form onSubmit={(e) => void handleSubmit(e)} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <div>
              <label style={{ display: "block", fontSize: 13, fontWeight: 700, color: "#334e68", marginBottom: 4 }}>Topic / Title</label>
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g. Shipping, Returns, Support"
                style={{ width: "100%", padding: "8px 12px", borderRadius: 6, border: "1px solid #cbd5e1", boxSizing: "border-box" }}
              />
            </div>
            <div>
              <label style={{ display: "block", fontSize: 13, fontWeight: 700, color: "#334e68", marginBottom: 4 }}>Question / User Query</label>
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="e.g. How do I track my order?"
                style={{ width: "100%", padding: "8px 12px", borderRadius: 6, border: "1px solid #cbd5e1", boxSizing: "border-box" }}
              />
            </div>
            <div>
              <label style={{ display: "block", fontSize: 13, fontWeight: 700, color: "#334e68", marginBottom: 4 }}>Approved Answer</label>
              <textarea
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                rows={4}
                placeholder="e.g. You can track your order at planwell.online/track."
                style={{ width: "100%", padding: "8px 12px", borderRadius: 6, border: "1px solid #cbd5e1", boxSizing: "border-box", fontFamily: "inherit" }}
              />
            </div>
            <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
              <div style={{ flex: 1 }}>
                <label style={{ display: "block", fontSize: 13, fontWeight: 700, color: "#334e68", marginBottom: 4 }}>Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  style={{ width: "100%", padding: "8px 12px", borderRadius: 6, border: "1px solid #cbd5e1" }}
                >
                  <option value="faq">FAQ</option>
                  <option value="policy">Policy</option>
                  <option value="product">Product Info</option>
                  <option value="service">Service</option>
                </select>
              </div>
              <div style={{ paddingTop: 18 }}>
                <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13, fontWeight: 700, color: "#334e68", cursor: "pointer" }}>
                  <input
                    type="checkbox"
                    checked={published}
                    onChange={(e) => setPublished(e.target.checked)}
                  />
                  Published
                </label>
              </div>
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
              <button
                type="submit"
                style={{ padding: "10px 16px", borderRadius: 8, border: 0, background: "#007a99", color: "white", fontWeight: 700, cursor: "pointer" }}
              >
                {editingRef ? "Update Article" : "Create Article"}
              </button>
              {editingRef && (
                <button
                  type="button"
                  onClick={resetForm}
                  style={{ padding: "10px 16px", borderRadius: 8, border: "1px solid #9fb3c8", background: "white", color: "#486581", fontWeight: 700, cursor: "pointer" }}
                >
                  Cancel
                </button>
              )}
            </div>
          </form>
        </div>

        <div>
          <h3 style={{ marginTop: 0, color: "#102a43" }}>Published Knowledge Articles ({articles.length})</h3>
          {articles.length === 0 ? (
            <div style={{ padding: 24, textAlign: "center", border: "1px dashed #cbd5e1", borderRadius: 8, color: "#64748b" }}>
              <p style={{ margin: "0 0 8px" }}>No dynamic articles in database yet.</p>
              <small>Live agents currently fall back to the approved static FAQ catalog.</small>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 12, maxHeight: 420, overflowY: "auto", paddingRight: 4 }}>
              {articles.map((art) => (
                <div
                  key={art.article_ref}
                  style={{
                    padding: 14,
                    borderRadius: 8,
                    border: "1px solid #e2e8f0",
                    background: art.published ? "#f8fafc" : "#f1f5f9",
                    borderLeft: `4px solid ${art.published ? "#007a99" : "#94a3b8"}`,
                  }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                    <span style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", color: "#007a99", background: "#e0f2fe", padding: "2px 6px", borderRadius: 4 }}>
                      {art.topic} ({art.category})
                    </span>
                    <span style={{ fontSize: 11, color: art.published ? "#16a34a" : "#64748b", fontWeight: 600 }}>
                      {art.published ? "● Published" : "○ Draft"}
                    </span>
                  </div>
                  <strong style={{ display: "block", fontSize: 14, color: "#1e293b", marginBottom: 4 }}>{art.question}</strong>
                  <p style={{ margin: "0 0 10px", fontSize: 13, color: "#475569", lineHeight: 1.4 }}>{art.answer}</p>
                  <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
                    <button
                      onClick={() => startEdit(art)}
                      style={{ padding: "4px 8px", fontSize: 12, borderRadius: 4, border: "1px solid #cbd5e1", background: "white", cursor: "pointer", fontWeight: 600 }}
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => void handleDelete(art.article_ref)}
                      style={{ padding: "4px 8px", fontSize: 12, borderRadius: 4, border: "1px solid #fca5a5", background: "#fef2f2", color: "#dc2626", cursor: "pointer", fontWeight: 600 }}
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function Governance() {
  return (
    <section style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 16 }}>
      <article style={cardStyle}>
        <h2 style={{ marginTop: 0 }}>Approved knowledge</h2>
        <p>Support answers remain limited to approved FAQ context. Publishing and version history are recorded for every change.</p>
      </article>
      <article style={cardStyle}>
        <h2 style={{ marginTop: 0 }}>Audit trail</h2>
        <p>Access, Front Desk, and protected API activity create durable audit evidence with correlation tracking.</p>
      </article>
      <article style={cardStyle}>
        <h2 style={{ marginTop: 0 }}>Out of scope here</h2>
        <p>SSH keys, Oracle controls, database credentials, and raw secrets stay in restricted infrastructure operations—not in this workspace.</p>
      </article>
    </section>
  );
}

function Status({ label, value, detail }: { label: string; value: string; detail: string }) {
  return (
    <article style={cardStyle}>
      <small style={{ color: "#486581", fontWeight: 700, textTransform: "uppercase", letterSpacing: 1 }}>{label}</small>
      <h2 style={{ margin: "10px 0 8px", color: "#007a99" }}>{value}</h2>
      <p style={{ margin: 0, color: "#486581", lineHeight: 1.5 }}>{detail}</p>
    </article>
  );
}

function tokenPermissions(token: string): string[] {
  try {
    const payload = token.split(".")[1];
    if (!payload) return [];
    const claims = JSON.parse(atob(payload.replace(/-/g, "+").replace(/_/g, "/"))) as { permissions?: unknown; scope?: unknown };
    const permissions = Array.isArray(claims.permissions) ? claims.permissions.filter((item): item is string => typeof item === "string") : [];
    const scope = typeof claims.scope === "string" ? claims.scope.split(" ").filter(Boolean) : [];
    return [...new Set([...scope, ...permissions])].sort();
  } catch {
    return [];
  }
}
