"""Protected dynamic knowledge base & FAQ management API for workspace owners."""

from __future__ import annotations

import json
import uuid
from collections.abc import Callable, Mapping
from typing import Any, Literal, cast
from urllib.parse import parse_qs

from ai_workforce_data.postgres_store import PostgresTenantStore

from .b1 import (
    AuditEvent,
    AuditSink,
    AuthenticationError,
    AuthorizationError,
    IdentityVerifier,
    MembershipDirectory,
)


class KnowledgeManagementApi:
    route_ref = "agent.knowledge-management.v1"
    read_permissions = frozenset({"platform.owner", "platform.front-desk.configure", "agent.context.read"})
    write_permissions = frozenset({"platform.owner", "platform.front-desk.configure"})

    def __init__(
        self,
        verifier: IdentityVerifier,
        memberships: MembershipDirectory,
        store: PostgresTenantStore,
        audit_sink: AuditSink,
        correlation_factory: Callable[[], str] = lambda: str(uuid.uuid4()),
    ) -> None:
        self._verifier = verifier
        self._memberships = memberships
        self._store = store
        self._audit_sink = audit_sink
        self._correlation_factory = correlation_factory

    def __call__(
        self, environ: Mapping[str, object], start_response: Callable[..., object]
    ) -> list[bytes]:
        correlation_ref = self._correlation_factory()
        headers = [("Content-Type", "application/json"), ("X-Correlation-Id", correlation_ref)]
        path = str(environ.get("PATH_INFO", ""))
        if path != "/v1/owner/knowledge":
            return self._respond(start_response, "404 Not Found", headers, {"error": "not_found"})

        method = str(environ.get("REQUEST_METHOD", "GET")).upper()
        try:
            identity = self._verifier.verify(cast(str | None, environ.get("HTTP_AUTHORIZATION")))
            membership = self._memberships.resolve(identity.principal_ref)
            tenant_ref = membership.tenant_ref
            permissions = membership.permissions

            if method == "GET":
                if not (self.read_permissions & permissions):
                    self._record_audit(correlation_ref, "denied", "forbidden", identity.principal_ref, tenant_ref)
                    return self._respond(start_response, "403 Forbidden", headers, {"error": "forbidden"})
                
                articles = self._store.list_knowledge_articles(tenant_ref, published_only=False)
                self._record_audit(correlation_ref, "allowed", "knowledge_articles_listed", identity.principal_ref, tenant_ref)
                return self._respond(
                    start_response,
                    "200 OK",
                    headers,
                    {
                        "status": "ok",
                        "tenant_ref": tenant_ref,
                        "articles": [
                            {
                                "article_ref": a.article_ref,
                                "topic": a.topic,
                                "question": a.question,
                                "answer": a.answer,
                                "category": a.category,
                                "published": a.published,
                                "created_by": a.created_by,
                                "updated_at": a.updated_at,
                            }
                            for a in articles
                        ],
                    },
                )

            if method == "POST":
                if not (self.write_permissions & permissions):
                    self._record_audit(correlation_ref, "denied", "forbidden", identity.principal_ref, tenant_ref)
                    return self._respond(start_response, "403 Forbidden", headers, {"error": "forbidden"})

                body = self._read_json(environ)
                question = str(body.get("question", "")).strip()
                answer = str(body.get("answer", "")).strip()
                topic = str(body.get("topic", "")).strip() or "General"
                category = str(body.get("category", "")).strip() or "faq"
                published = bool(body.get("published", True))
                article_ref = str(body.get("article_ref", "")).strip() or str(uuid.uuid4())

                if not question or not answer:
                    return self._respond(
                        start_response, "400 Bad Request", headers, {"error": "question_and_answer_required"}
                    )

                self._store.upsert_knowledge_article(
                    article_ref=article_ref,
                    tenant_ref=tenant_ref,
                    topic=topic,
                    question=question,
                    answer=answer,
                    category=category,
                    published=published,
                    created_by=identity.principal_ref,
                )
                self._record_audit(
                    correlation_ref,
                    "allowed",
                    f"knowledge_article_saved:{article_ref}",
                    identity.principal_ref,
                    tenant_ref,
                )
                return self._respond(
                    start_response,
                    "200 OK",
                    headers,
                    {"status": "ok", "article_ref": article_ref},
                )

            if method == "DELETE":
                if not (self.write_permissions & permissions):
                    self._record_audit(correlation_ref, "denied", "forbidden", identity.principal_ref, tenant_ref)
                    return self._respond(start_response, "403 Forbidden", headers, {"error": "forbidden"})

                query = parse_qs(str(environ.get("QUERY_STRING", "")))
                article_ref_list = query.get("article_ref")
                if not article_ref_list or not article_ref_list[0].strip():
                    return self._respond(
                        start_response, "400 Bad Request", headers, {"error": "article_ref_required"}
                    )
                article_ref = article_ref_list[0].strip()
                deleted = self._store.delete_knowledge_article(tenant_ref, article_ref)
                self._record_audit(
                    correlation_ref,
                    "allowed",
                    f"knowledge_article_deleted:{article_ref}",
                    identity.principal_ref,
                    tenant_ref,
                )
                return self._respond(
                    start_response,
                    "200 OK",
                    headers,
                    {"status": "ok", "deleted": deleted, "article_ref": article_ref},
                )

            return self._respond(start_response, "405 Method Not Allowed", headers, {"error": "method_not_allowed"})

        except AuthenticationError:
            return self._respond(
                start_response,
                "401 Unauthorized",
                headers,
                {"error": "unauthorized"},
            )
        except AuthorizationError:
            try:
                self._record_audit(correlation_ref, "denied", "forbidden", identity.principal_ref if identity else None, membership.tenant_ref if membership else None)
            except Exception:
                pass
            return self._respond(
                start_response,
                "403 Forbidden",
                headers,
                {"error": "forbidden"},
            )
        except Exception as error:
            self._record_audit(correlation_ref, "denied", f"internal_error:{error}", None, None)
            return self._respond(start_response, "500 Internal Server Error", headers, {"error": "internal_error"})

    def _record_audit(
        self,
        correlation_ref: str,
        outcome: Any,
        reason: str,
        principal_ref: str | None,
        tenant_ref: str | None,
    ) -> None:
        self._audit_sink.record(
            AuditEvent(
                outcome=outcome,
                reason=reason,
                correlation_ref=correlation_ref,
                route_ref=self.route_ref,
                principal_ref=principal_ref,
                tenant_ref=tenant_ref,
            )
        )

    @staticmethod
    def _read_json(environ: Mapping[str, object]) -> dict[str, object]:
        try:
            length = int(str(environ.get("CONTENT_LENGTH") or "0"))
        except ValueError:
            length = 0
        stream = environ.get("wsgi.input")
        if length > 0 and hasattr(stream, "read"):
            data = stream.read(length)
            if data:
                return cast(dict[str, object], json.loads(data.decode("utf-8")))
        return {}

    @staticmethod
    def _respond(
        start_response: Callable[..., object],
        status: str,
        headers: list[tuple[str, str]],
        payload: dict[str, object],
    ) -> list[bytes]:
        encoded = json.dumps(payload).encode("utf-8")
        headers.append(("Content-Length", str(len(encoded))))
        start_response(status, headers)
        return [encoded]
